is_int = lambda obj: isinstance(obj, int)
lowbit = lambda n: n & -n