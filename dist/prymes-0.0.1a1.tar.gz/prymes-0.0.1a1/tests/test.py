from functools import wraps
from asyncio import run, timeout
from prymes import *

class test:
    n = 0
    tests = []

    def __init__(self, times=1, timeout=1):
        test.n += 1
        self._id, self.times, self.timeout = test.n, times, timeout

    def __call__(self, f):
        @wraps(f)
        async def wrapper():
            print(end=f'Test #{self._id}: {f.__name__}... ')
            try:
                for _ in range(self.times):
                    async with timeout(self.timeout):
                        await f()
                print('Passed')
                return 0
            except TimeoutError:
                print('Failed: Timed Out')
                return 1
            except Exception as e:
                print(f'Failed: {e}')
                return 1
        test.tests.append(wrapper)
        return wrapper
    
    @classmethod
    async def execute_all(cls):
        s = cls.n
        for t in cls.tests:
            s -= await t()
        print(f'Passed {s}/{cls.n}')

@test()
async def primality_test():
    assert 480_194_653 in P
    assert 20_074_069 not in P
    assert 8_718_775_377_449 in P
    assert 8_651_776_913_431 not in P
    assert 3_315_293_452_192_821_991 in P
    assert 1_152_965_996_591_997_761 not in P
    assert 10_000_003_599_249_373_469 not in P
    assert 48_112_959_837_082_048_697 in P, '0'
    assert 54_673_257_461_630_679_457 in P, '1'
    assert 29_497_513_910_652_490_397 in P
    assert 40_206_835_204_840_513_073 in P
    assert 12_764_787_846_358_441_471 in P
    assert 71_755_440_315_342_536_873 in P
    assert 45_095_080_578_985_454_453 in P
    assert 27_542_476_619_900_900_873 in P
    assert 66_405_897_020_462_343_733 in P
    assert 36_413_321_723_440_003_717 in P

run(test.execute_all())